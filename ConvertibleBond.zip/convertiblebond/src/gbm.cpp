//[[Rcpp::plugins(cpp11)]]
//[[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
using namespace Rcpp;

class GBM{
public:
  GBM(double s0, double r, double q, double sigma, double dt) {
    this->s0 = s0;
    this->r = r;
    this->q = q;
    this->sigma = sigma;
    this->dt = dt;
    this->initialize();
  }

  arma::mat simulate(arma::mat randMat) {
    arma::mat samples = arma::zeros(randMat.n_rows + 1,randMat.n_cols);
    samples.row(0).fill(this->s0);
    samples.submat(1,0,randMat.n_rows,randMat.n_cols - 1) = arma::exp(this->logDrift + this->logDiffusion * randMat);
    return arma::cumprod(samples,0);
  }

  void setParameter(std::string name, double value) {
    if(name == "s0") {
      this->s0 = value;
    }
    else if(name == "r") {
      this->r = value;
    }
    else if(name == "q") {
      this->q = value;
    }
    else if(name == "sigma") {
      this->sigma = value;
    }
    else if(name == "dt") {
      this->dt = value;
    }

    this->initialize();
  }

  double getParameter(std::string name) {
    double value = 0.0;

    if(name == "s0") {
      value = this->s0 ;
    }
    else if(name == "r") {
      value = this->r;
    }
    else if(name == "q") {
      value = this->q;
    }
    else if(name == "sigma") {
      value = this->sigma;
    }
    else if(name == "dt") {
      value = this->dt;
    }
    else {
      Rcpp::stop("unknown parameter name found");
    }

    return value;
  }

  void addValue(std::string name, double value) {
    this->setParameter(name,this->getParameter(name) + value);
    this->initialize();
  }

private:
  double s0           = 0.0;
  double r            = 0.0;
  double q            = 0.0;
  double sigma        = 0.0;
  double dt           = 0.0;
  double logDrift     = 0.0;
  double logDiffusion = 0.0;

  void initialize() {
    this->logDrift = (this->r - this->q - 0.5 * this->sigma * this->sigma) * this->dt;
    this->logDiffusion = this->sigma * std::sqrt(this->dt);
  }
};

RCPP_MODULE(BSModel){
  class_<GBM>("GBM")
  .constructor<double,double,double,double,double>()
  .method("getParameter",&GBM::getParameter)
  .method("setParameter",&GBM::setParameter)
  .method("addValue",&GBM::addValue)
  .method("simulate",&GBM::simulate)
  ;
}




Conversion <- function(exercise.time,conversion.price) {
  new(Class            = "Conversion",
      exercise.time    = exercise.time,
      conversion.price = conversion.price)
}
SetCreditSpreadCurve <- function(samples,instrument.basket ,model,value.date){
  
  PricingEngine <- SetPricingEngine()
  bond.floor    <- instrument.basket[["bond.floor"]]
  
  CalculatePrice <- function(credit.spread) {
    
    instrument.basket[["bond.floor"]]@credit.spread <- credit.spread
    
    PricingEngine(samples           = samples,
                  instrument.basket = instrument.basket,
                  model             = bs.model,
                  value.date        = value.date)[["cb.price"]]
  }
  
  function(from,to,by) {
    credit.spreads <- seq(from = from,
                          to   = to,
                          by   = by)
    
    cb.prices <- vapply(X         = credit.spreads,
                        FUN       = CalculatePrice,
                        FUN.VALUE = numeric(1))
    
    list(credit.spreads = credit.spreads,
         cb.prices      = cb.prices)
  }
}
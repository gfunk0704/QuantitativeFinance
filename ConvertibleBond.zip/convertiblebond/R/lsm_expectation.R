SetExpectation <- function(x.powers = 0:1) {
  
  function(x,y) {
    x.mat <- vapply(X         = x.powers,
                    FUN       = function(pow) x ^ pow,
                    FUN.VALUE = numeric(length(x)))
    
    x.t.x  <- crossprod(x.mat)
    x.t.y  <- crossprod(x.mat, y) 
    params <- solve(x.t.x, x.t.y) 
    
    x.mat %*% params
  }
}
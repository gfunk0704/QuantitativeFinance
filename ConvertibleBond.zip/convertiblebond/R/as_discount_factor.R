AsDiscountFactor <- function(r,credit.spread,dt) {
  discount.scale <- - (r + credit.spread) * dt
  
  function(days) {
    exp(discount.scale * days)
  }
}
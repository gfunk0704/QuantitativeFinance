SetRNG <- function(seed.input) {
  
  seed <- as.integer(seed.input)
  
  function(rows,cols) {
    set.seed(10)
    matrix(data = urnorm(rows * cols),
           nrow = rows,
           ncol = cols)
  }
}

AntitheticVariatesMethod <- function(seed.input) {
  
  RNG <- SetRNG(seed.input)
  
  function(steps,paths) {
    half.mat <- RNG(steps,paths / 2L)
    cbind(half.mat,-half.mat)
  }
}
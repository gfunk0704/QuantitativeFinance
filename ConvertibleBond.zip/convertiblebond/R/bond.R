ZeroCouponBond <- function(par.value,
                           credit.spread,
                           expiry.date,
                           issue.date,
                           day.count) {
  
  new(Class         = "ZeroCouponBond",
      par.value     = par.value,
      credit.spread = credit.spread,
      expiry.date   = expiry.date,
      issue.date    = issue.date,
      day.count     = day.count)
}

CouponBond <- function(par.value,
                       credit.spread,
                       expiry.date,
                       issue.date,
                       day.count,
                       coupon.rate,
                       coupon.dates) {
  
  new(Class         = "CouponBond",
      par.value     = par.value,
      credit.spread = credit.spread,
      expiry.date   = expiry.date,
      issue.date    = issue.date,
      day.count     = day.count,
      coupon.rate   = coupon.rate,
      coupon.dates  = coupon.dates)
}

CBAssetSwap <- function(par.value,
                        credit.spread,
                        expiry.date,
                        issue.date,
                        day.count,
                        coupon.rate,
                        coupon.dates) {
  
  new(Class         = "CBAssetSwap",
      par.value     = par.value,
      credit.spread = credit.spread,
      expiry.date   = expiry.date,
      issue.date    = issue.date,
      day.count     = day.count,
      coupon.rate   = coupon.rate,
      coupon.dates  = coupon.dates)
}



setMethod(
  f          = "GenerateCashFlow",
  signature  = signature(bond       = "ZeroCouponBond",
                         value.date = "Date"),
  definition = function(bond,value.date) {
    end.step           <- as.integer(bond@expiry.date - value.date) + 1L
    cashflow           <- rep_len(x          = 0,
                                   length.out = end.step)
    cashflow[end.step] <- bond@par.value
    cashflow
  } 
)

setMethod(
  f          = "GenerateCashFlow",
  signature  = signature(bond       = "CouponBond",
                         value.date = "Date"),
  definition = function(bond,value.date) {
    cashflow   <- callNextMethod(bond       = bond,
                                 value.date = value.date)
    
    par.value       <- bond@par.value
    coupon.dates    <- bond@coupon.dates
    coupon.step     <- as.integer(coupon.dates - value.date) + 1L
    coupon.step     <- coupon.step[coupon.step > 0L]
    year.fraction   <- diff(c(0L,as.integer(coupon.dates - bond@issue.date))) / GetDaysInYear(bond@day.count)
    coupon.cashflow <- par.value * bond@coupon.rate * year.fraction
    coupon.cashflow <- tail(coupon.cashflow,length(coupon.step))
    
    if(is(bond,"CBAssetSwap")) {
      cashflow[which(cashflow != 0)] <- 0
    }
    
    cashflow[coupon.step] <- coupon.cashflow
    cashflow
  } 
)

setMethod(
  f = "CBInstrumentBasket",
  signature = signature(bond.floor        = "ZeroCouponBond",
                        conversion        = "Conversion",
                        call              = "CallOrEmpty",
                        put               = "PutOrEmpty",
                        soft.barrier.call = "SoftBarrierCallOrEmpty",
                        cbas              = "CBAssetSwap",
                        value.date        = "Date"),
  def  = function(bond.floor,
                  conversion,
                  call,
                  put,
                  soft.barrier.call,
                  cbas,
                  value.date) {
    
    par.value <- bond.floor@par.value
    
    cb.call   <- ToFunction(object     = call,
                            par.value  = par.value,
                            value.date = value.date)
    
    cb.put    <- ToFunction(object     = put,
                            par.value  = par.value,
                            value.date = value.date)
    
    cb.soft.barrier.call <- ToFunction(object     = soft.barrier.call,
                                       par.value  = par.value,
                                       value.date = value.date)
    
    list(bond.floor        = bond.floor,
         conversion        = conversion,
         Call              = cb.call,
         Put               = cb.put,
         cbas              = cbas,
         SoftBarrierCall = cb.soft.barrier.call)
  } 
)

FindFirst <- function(data,op,value) {
  comparison <- op(data,value)
  position   <- which.max(comparison)
  if(position == 1L && (!comparison[1L])) {
    0
  }
  else {
    position
  }
}


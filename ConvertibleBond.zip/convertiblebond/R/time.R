Dates <- function(input.dates) {
  dates <- sort(unique(input.dates))
  new(Class = "Dates",
      dates = dates)
}

TimePeriod <- function(start.date,end.date) {
  new(Class      = "TimePeriod",
      start.date = start.date,
      end.date   = end.date)
}

setMethod(
  f          = "ToStep",
  signature  = signature(value.date = "Date",
                         time       = "Dates"),
  definition = function(value.date,time) {
    
    dates <- time@dates
    
    if (value.date > tail(dates,1)) {
      integer(0)
    }
    else {
      steps <- as.integer(value.date - dates) + 1L
      steps[steps > 0L]
    }
  } 
)

setMethod(
  f          = "ToStep",
  signature  = signature(value.date = "Date",
                         time       = "TimePeriod"),
  definition = function(value.date,time) {
    
    end.date   <- time@end.date
    start.date <- time@start.date
    
    if (value.date > end.date) {
      integer(0)
    }
    else {
      begin.date <- max(start.date,value.date)
      seq_len(as.integer(end.date - begin.date) + 1L)
    }
  } 
)

setMethod(
  f          = "CreateInTimeSet",
  signature  = signature(value.date = "Date",
                         time       = "Dates"),
  definition = function(value.date,time) {
    
    setp.set <- ToStep(value.date,time)
    
    function(step) {
      step %in% setp.set
    }
  } 
)

setMethod(
  f          = "CreateInTimeSet",
  signature  = signature(value.date = "Date",
                         time       = "TimePeriod"),
  definition = function(value.date,time) {
    
    begin.step <- max(as.integer(time@start.date - value.date),0) + 1L
    end.step   <- max(as.integer(time@end.date - value.date) + 1L,0)
    
    function(step) {
      (step >= begin.step) && (step <= end.step)
    }
    
  } 
)


setMethod(
  f = "GetDate",
  signature   = signature(time  = "TimePeriod",
                          index = "Dates"),
  definition  = function(time,index) {
    
    dates <- time@dates
    
    switch(tolower(index),
           "first" = min(dates),
           "last"  = max(dates),
           stop("unknown index for time object"))
  }
)

setMethod(
  f = "GetDate",
  signature   = signature(time  = "TimePeriod",
                          index = "character"),
  definition  = function(time,index) {
    switch(tolower(index),
           "first" = time@start.date,
           "last"  = time@end.date,
           stop("unknown index for time object"))
  }
)
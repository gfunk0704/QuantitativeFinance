LSMAlgorithm <- function(samples,instrument.basket,model,value.date) {
  
  n.path         <- ncol(samples)
  n.step         <- nrow(samples)
  par.value      <- instrument.basket[["bond.floor"]]@par.value
  exercise.steps <- ToStep(value.date,instrument.basket[["conversion"]]@exercise.time)
  
  DiscountFactor  <- AsDiscountFactor(r             = model$getParameter("r"),
                                      credit.spread = instrument.basket[["bond.floor"]]@credit.spread,
                                      dt            = model$getParameter("dt"))
  
  discount.factor <- DiscountFactor(1)
  
  conversion.samples <- par.value / instrument.basket[["conversion"]]@conversion.price * samples
  instruemnt.names   <- names(instrument.basket) 
  Expectation        <- SetExpectation()
  Call               <- instrument.basket[["Call"]]
  Put                <- instrument.basket[["Put"]]
  SoftBarrierCall    <- instrument.basket[["SoftBarrierCall"]]
  payoff             <- pmax(conversion.samples[n.step,],par.value) * discount.factor
  stopping.rule      <- rep_len(x          = n.step,
                                length.out = n.path)
  
  for(step in rev(exercise.steps)[-1]) {
    try(
      expr = {
        conversion.value   <- conversion.samples[step,]
        exp.continuation   <- Expectation(conversion.value, payoff)
        
        if(Call("CanExercise",step)) {
          call.exe                   <- Call("ExercisePayoff") > exp.continuation
          exp.continuation[call.exe] <- Call("ExercisePayoff")
          payoff[call.exe]           <- Call("ExercisePayoff")
          stopping.rule[call.exe]    <- step
        } 
        
        do.convert                <- exp.continuation < conversion.value
        payoff[do.convert]        <- conversion.value[do.convert]
        stopping.rule[do.convert] <- step
        
        if(Put("CanExercise",step)) {
          put.exe                <- Put("ExercisePayoff") > pmax(exp.continuation, conversion.value)
          payoff[put.exe]        <- Put("ExercisePayoff")
          stopping.rule[put.exe] <- step
        }
        
        if(SoftBarrierCall("CanExercise",step)) {
          has.trigger.event                <- SoftBarrierCall("hsaTriggerEvent",step,samples)
          payoff[has.trigger.event]        <- SoftBarrierCall("ExercisePayoff")
          stopping.rule[has.trigger.event] <- step
        }
      }
    )
    
    payoff <- payoff * discount.factor
  }
  
  list(payoff         = payoff,
       stopping.rule  = stopping.rule,
       DiscountFactor = DiscountFactor)
}
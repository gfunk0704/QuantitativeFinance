EmptyInstrument <- function(){
  new(Class = "EmptyInstrument")
}

CBOption <- function(strike.ratio,
                     exercise.time,
                     type) {
  
  
  class.name <- switch(tolower(type),
                       "call" = "CBCall",
                       "put"  = "CBPut",
                       stop("unknown type of option found"))
  
  new(Class         = class.name,
      strike.ratio  = strike.ratio,
      exercise.time = exercise.time)
}

CBSoftBarrierCall <- function(strike.ratio,
                              exercise.time,
                              trigger,
                              grace.period) {
  
  new(Class = "CBSoftBarrierCall",
      strike.ratio  = strike.ratio,
      exercise.time = exercise.time,
      trigger       = trigger,
      grace.period  = as.integer(grace.period))
} 


SetHasTriggerEvent <- function(trigger,grace.period) {
  
  function(step,samples) {
    min.value <- apply(X      = samples[(step - grace.period + 1L):step,],
                       MARGIN = 2L,
                       FUN    = min)
    min.value >= trigger
  }
}

GetInfo <- function(object,...) {
  more.args       <- list(...)
  exercise.payoff <- more.args[["par.value"]] * object@strike.ratio
  InTimeSet       <- CreateInTimeSet(more.args[["value.date"]],object@exercise.time)
  
  if(is(object,"CBSoftBarrierCall")) {
    HasTriggerEvent <- SetHasTriggerEvent(object@trigger,object@grace.period)
  }
  else {
    HasTriggerEvent <- NULL
  }
  
  list(exercise.payoff = exercise.payoff,
       InTimeSet       = InTimeSet)
}

setMethod(
  f          = "ToFunction",
  signature  = signature(object = "CBOption"),
  definition = function(object,...) {
    info            <- GetInfo(object,...)
    exercise.payoff <- info[["exercise.payoff"]]
    InTimeSet       <- info[["InTimeSet"]]
    HasTriggerEvent <- info[["HasTriggerEvent"]]
    function(use.method,...) {
      switch(use.method,
             "CanExercise"     = InTimeSet(...),
             "ExercisePayoff"  = exercise.payoff,
             "HasTriggerEvent" = HasTriggerEvent(...))
    }
  }
)

setMethod(
  f          = "ToFunction",
  signature  = signature(object = "EmptyInstrument"),
  definition = function(object,...) {
    function(use.method,...) {
      switch(use.method,
             "CanExercise"     = FALSE)
    }
  }
)


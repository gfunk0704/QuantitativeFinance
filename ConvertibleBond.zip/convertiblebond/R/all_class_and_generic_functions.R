setClass(
  Class = "Time"
)

setClass(
  Class          = "Dates",
  contain        = "Time",
  representation = representation(
    dates = "Date"
  )
)

setClass(
  Class          = "TimePeriod",
  contain        = "Time",
  representation = representation(
    start.date = "Date",
    end.date   = "Date"
  ),
  validity = function(object) {
    if(object@end.date < object@start.date) {
      "end.date must be greater than start.date"
    }
    else {
      TRUE
    }
  }
)

setClass(
  Class          = "ZeroCouponBond",
  representation =  representation(
    par.value     = "numeric",
    credit.spread = "numeric",
    expiry.date   = "Date",
    issue.date    = "Date",
    day.count     = "character"
  ),
  validity = function(object) {
    if(object@issue.date >= object@expiry.date) {
      return("issue.date must be earlier then expiry.date")
    }
    
    if(!IsDayCount(object@day.count)) {
      return("unknown type of day count convention found")
    }
    
    TRUE
  }
)

setClass(
  Class    = "CouponBond",
  contains = "ZeroCouponBond",
  representation = representation(
    coupon.rate  = "numeric",
    coupon.dates = "Date"
  )
)

setClass(
  Class    = "CBAssetSwap",
  contains = "CouponBond"
)

setClass(
  Class          = "IFinancialInstrument",
  representation = representation(
    exercise.time    = "Time",
    "VIRTUAL"
  )
)

setClass(
  Class          = "Conversion",
  contain        = "IFinancialInstrument",
  representation = representation(
    conversion.price = "numeric"
  )
)

setClass(
  Class           = "CBOption",
  contain         = "IFinancialInstrument",
  representation  = representation(
    strike.ratio  = "numeric",
    "VIRTUAL"
  )
)

setClass(
  Class    = "EmptyInstrument",
  representation = representation(
    empty = "integer"
  ),
  prototype = prototype(
    empty = integer(0)
  )
)

setClass(
  Class    = "CBCall",
  contains = "CBOption"
)

setClass(
  Class    = "CBPut",
  contains = "CBOption"
)

setClass(
  Class          = "CBSoftBarrierCall",
  contains       = "CBOption",
  representation = representation(
    trigger      = "numeric",
    grace.period = "integer"
  ),
  validity       = function(object) {
    if(object@grace.period > 0) {
      TRUE
    }
    else {
      "grace.period must be positive"
    }
  }
)

setClassUnion(
  name    = "CallOrEmpty",
  members = c("CBCall","EmptyInstrument") 
)

setClassUnion(
  name    = "PutOrEmpty",
  members = c("CBPut","EmptyInstrument") 
)

setClassUnion(
  name    = "SoftBarrierCallOrEmpty",
  members = c("CBSoftBarrierCall","EmptyInstrument") 
)


setGeneric(
  name = "ToFunction",
  def  = function(object,...) {
    standardGeneric("ToFunction")
  } 
)

setGeneric(
  name = "CBInstrumentBasket",
  def  = function(bond.floor,
                  conversion,
                  call,
                  put,
                  soft.barrier.call,
                  cbas,
                  value.date) {
    standardGeneric("CBInstrumentBasket")
  } 
)

setGeneric(
  name      = "ToStep",
  def       = function(value.date,time) {
    standardGeneric("ToStep")
  }
)

setGeneric(
  name      = "CreateInTimeSet",
  def       = function(value.date,time) {
    standardGeneric("CreateInTimeSet")
  }
)

setGeneric(
  name = "GenerateCashFlow",
  def  = function(bond,value.date) {
    standardGeneric("GenerateCashFlow")
  } 
)

setGeneric(
  name = "GetDate",
  def  = function(time,index) {
    standardGeneric("GetDate")
  }
)

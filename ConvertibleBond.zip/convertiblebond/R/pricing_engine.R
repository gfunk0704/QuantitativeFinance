

SetPricingEngine <- function(outputs = "cb.price") {
  
  SetCBPriceCalculator <- function(conversion,DiscountFactor,value.date) {
    conversion.start <- GetDate(time  = conversion@exercise.time,
                               index = "first")
    days.between     <- max(as.integer(conversion.start - value.date),0)
    
    function(payoff) {
      mean(payoff) * DiscountFactor(days.between)
    }
  }
  
  SetCBASPayoffClaculator <- function(future.cashflow) {
    
    cashflow.steps <- which(future.cashflow != 0)
    
    function(stopping.step) {
      
      accu.cashflow <- sum(future.cashflow[1:stopping.step])
      
      if(stopping.step %in% cashflow.steps) {
        accu.cashflow
      }
      else {
        accu.cashflow + future.cashflow[FindFirst(cashflow.steps,`>`,stopping.step)]
      }
    }
  }
  
  function(samples,instrument.basket,model,value.date) {
    
    lsm.result     <- LSMAlgorithm(samples,instrument.basket,model,value.date)
    DiscountFactor <- lsm.result[["DiscountFactor"]]
    stopping.rule  <- lsm.result[["stopping.rule"]]
  
    CalculateCBPrice <- SetCBPriceCalculator(conversion     = instrument.basket[["conversion"]],
                                             DiscountFactor = lsm.result[["DiscountFactor"]],
                                             value.date     = value.date)
      
    result.list <- list(cb.price           = NULL,
                        cbas.price         = NULL,
                        option.on.cb.price = NULL)
    
    for(result.name in outputs) {
      switch(result.name,
             "cb.price"           = {
               result.list[[result.name]] <- CalculateCBPrice(lsm.result[["payoff"]])
             },
             "option.on.cb.price" = {
               
               if(is.null(result.list[["cb.price"]])) {
                 result.list[["cb.price"]] <- CalculateCBPrice(lsm.result[["payoff"]])
               }
               
               bond.floor       <- instrument.basket[["bond.floor"]]
               days             <- as.integer(bond.floor@expiry.date - value.date)
               bond.floor.price <- bond.floor@par.value * DiscountFactor(days)
               result.list[[result.name]] <- result.list[["cb.price"]] - bond.floor.price
             },
             "cbas.price" = {
               cbas          <- instrument.basket[["cbas"]]
               cbas.cashflow <- GenerateCashFlow(bond       = cbas,
                                                 value.date = value.date)
               
               CBASPayoffClaculator       <- SetCBASPayoffClaculator(cbas.cashflow)
               result.list[[result.name]] <- mean(vapply(X         = stopping.rule,
                                                         FUN       = CBASPayoffClaculator,
                                                         FUN.VALUE = numeric(1)))
             })
    }
    
    result.list
  }
}


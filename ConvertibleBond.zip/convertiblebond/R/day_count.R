IsDayCount <- function(x) {
  x %in% c("ACT/365","ACT/360")
}

GetDaysInYear <- function(day.count) {
  if(IsDayCount(day.count)) {
    switch(day.count,
           "ACT/365" = 365,
           "ACT/360" = 360)
  }
  else {
    stop("unknown day count convention found")
  }
}